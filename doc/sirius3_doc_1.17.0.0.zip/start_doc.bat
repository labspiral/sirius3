setlocal

cd /d "%~dp0"

set PORT=8081
set DOCROOT=_site

taskkill /IM CivetWeb.exe /F >nul 2>&1

echo.
echo Starting SIRIUS3 Documentation Server...
echo.
echo URL: http://localhost:%PORT%
echo.

start "" http://localhost:%PORT%

.\CivetWeb.exe -document_root "%DOCROOT%" -listening_ports %PORT%

pause